package com.techm.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDemoApplication {

	public static void main(String[] args) {
		//System.out.println("mainnnnnnnnnnnnnnnnnnnn");
		SpringApplication.run(BootDemoApplication.class, args);
	}

}
