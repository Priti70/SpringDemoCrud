package com.techm.main.employeeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.techm.main.empEntity.EmployeeEntity;
import com.techm.main.empRepo.EmployeeRepo;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepo empRepo;
	public Object setEmployeeDetails(EmployeeEntity empEntity) {
		//System.out.println("clkkhhhhhhhh");
		empRepo.save(empEntity);
		return empEntity;
	}


}
