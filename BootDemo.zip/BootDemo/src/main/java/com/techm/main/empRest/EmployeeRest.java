package com.techm.main.empRest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.techm.main.empEntity.EmployeeEntity;
import com.techm.main.employeeService.EmployeeService;

@RestController
@RequestMapping("/common")
public class EmployeeRest {
	@Autowired
   private EmployeeService empService;
	@RequestMapping(value = "/empdetails",method = RequestMethod.POST)
	public ResponseEntity<?>setEmployeeDetails(@RequestBody EmployeeEntity empEntity)
	{	
		 ResponseEntity<?> response = null;
		 HttpHeaders headers=new HttpHeaders();
	     headers.add("Content-Type", "application/json; charset=UTF-8");
	     try
	     {	    	
	    	 response = new ResponseEntity<>(empService.setEmployeeDetails(empEntity), headers, HttpStatus.OK); 
	     }
	     catch (Exception e) {
	    	 response = new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	     }
		return response;	
	}

}
